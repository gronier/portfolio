# **<center>Projet Compteur de mots prodApp</center>** 


## Les membres de l'équipe

Ce groupe est constitué de 3 personnes:

- Lucie Caudron
- Corentin Gaspard
- Thibaut Gronier

## Comment lancer le programme:

Il faut lancer depuis vôtre IDE le fichier "Compteur.java" puis coller le votre texte choisi dans le terminal
