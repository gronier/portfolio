
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Compteur {
    static void creefile(String s) throws FileNotFoundException {
        PrintWriter out=new PrintWriter("texte.txt");
        out.println(s);
        out.close();
    }
    static void compteLigne(String fichierTexte){
        int nbMots = 0;
        String nomFichier = fichierTexte;
        try(Scanner scanner = new Scanner(new File(nomFichier))) {
            scanner.useDelimiter("\r");
            scanner.useLocale(Locale.US);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                line = line.toLowerCase().replaceAll("[?.!]", "~");
                String[] mots = line.split("~");
                for(int i = 0; i <= mots.length - 1; i++) {
                    nbMots++;

                }
            }
            System.out.println("Le texte comporte : "+nbMots+ " lignes.");
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    static void recurrence(String filename , String mot ) throws FileNotFoundException {
        try {
            String [] tab = mot.split(",");
            Scanner in = new Scanner(new File(filename));
            Map<String , Integer> map = new HashMap<>();
            while (in.hasNext()) {
                String p = in.next().toLowerCase().replaceAll("[0-9+/. ()\\-,\\[\\]\\s]", "");
                for(int i = 0 ; i<tab.length;i++){
                    if(tab[i].equals(p)){
                        if(map.containsKey(p)){
                            map.put(p,map.get(p)+1);
                        }else{
                            map.put(p,1);
                        }
                    }
                }
            }
            for (String all:map.keySet()
                 ) {
                System.out.println(all + " : " + map.get(all));
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static int compteMots(String filename) {
        List<String> mots = new ArrayList<>();
        try(Scanner in = new Scanner(new File(filename))) {
            in.useDelimiter(" ");
            in.useLocale(Locale.US);
            while(in.hasNext()) {
                String mot = in.next().toLowerCase().replaceAll("[0-9+/. ()\\-,\\[\\]\\s]", "");
                if(mot.length() > 4) mots.add(mot);
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }

        return mots.size();
    }

    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Mettre le texte voulu : ");
        Scanner t = new Scanner(System.in);
        String texte = t.nextLine();
        creefile(texte);
        Scanner scmot = new Scanner(System.in);
        System.out.println("------ { Compteur Mots } ------");
        System.out.println("Le texte comporte : " + compteMots("texte.txt") + " Mots");
        System.out.println("------ { Compte Ligne } ------");
        compteLigne("texte.txt");
        System.out.println("------ { Récurrence } ------");
        System.out.println("ecrire mots recurrent");
        recurrence( "texte.txt", scmot.next().toLowerCase());
        File f = new File("texte.txt");
        f.delete();
    }
}
